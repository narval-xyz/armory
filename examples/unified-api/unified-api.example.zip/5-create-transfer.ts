import dotenv from 'dotenv'
import minimist from 'minimist'
import { createTransfer } from './provider.utils'

dotenv.config()

const main = async () => {
  const args = minimist(process.argv.slice(2), {
    string: ['_']
  })
  const fromId = args._[0]
  const toId = args._[1]
  const assetType = args._[2]
  const amount = args._[3]

  const connectionId = process.env.CONNECTION_ID

  if (!connectionId) {
    console.error('Please provide CONNECTION_ID in your .env file')
    process.exit(1)
  }

  const transfer = await createTransfer(connectionId, {
    source: {
      type: 'account',
      id: fromId
    },
    destination: {
      type: 'account',
      id: toId
    },
    assetType,
    amount
  })

  console.dir(transfer)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
