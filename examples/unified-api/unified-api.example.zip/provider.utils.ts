import { Hex, PrivateKey } from '@narval-xyz/armory-sdk'
import { JwsdHeader } from '@narval-xyz/armory-sdk/signature'
import {
  CreateConnectionDto,
  InitiateConnectionDto,
  PendingConnectionDto,
  ProviderConnectionDto
} from '@narval-xyz/armory-sdk/src/lib/http/client/vault'
import {
  buildSignerForAlg,
  ed25519PrivateKeySchema,
  hash,
  hexToBase64Url,
  privateKeyToJwk,
  signJwsd
} from '@narval/signature'
import axios, { AxiosRequestConfig } from 'axios'
import dotenv from 'dotenv'
dotenv.config()

const CLIENT_ID = process.env.CLIENT_ID
const privKey = process.env.MASTER_PRIVATE_KEY
const BASE_URL = process.env.BASE_URL

if (!CLIENT_ID || !privKey || !BASE_URL) {
  throw new Error('Missing CLIENT_ID or MASTER_PRIVATE_KEY')
}

const jwk = privateKeyToJwk(privKey as Hex, 'EDDSA')

const MASTER_PRIVATE_KEY = {
  jwk,
  hex: privKey
}

export const getJwsd = async ({
  userPrivateJwk,
  baseUrl,
  requestUrl,
  accessToken,
  payload,
  htm
}: {
  userPrivateJwk: PrivateKey
  baseUrl?: string
  requestUrl: string
  accessToken?: string
  payload: object | string
  htm?: string
}) => {
  const now = Math.floor(Date.now() / 1000)

  const jwsdSigner = await buildSignerForAlg(userPrivateJwk)
  const jwsdHeader: JwsdHeader = {
    alg: userPrivateJwk.alg,
    kid: userPrivateJwk.kid,
    typ: 'gnap-binding-jwsd',
    htm: htm || 'POST',
    uri: `${baseUrl || BASE_URL}${requestUrl}`,
    created: now,
    ath: accessToken ? hexToBase64Url(hash(accessToken)) : undefined
  }

  const jwsd = await signJwsd(payload, jwsdHeader, jwsdSigner).then((jws) => {
    // Strip out the middle part for size
    const parts = jws.split('.')
    parts[1] = ''
    return parts.join('.')
  })

  return jwsd
}

export const authRequest = async (request: AxiosRequestConfig): Promise<AxiosRequestConfig> => {
  const jwsd = await getJwsd({
    userPrivateJwk: ed25519PrivateKeySchema.parse(MASTER_PRIVATE_KEY.jwk),
    payload: request?.data || {},
    htm: request.method,
    requestUrl: request.url || ''
  })

  return {
    ...request,
    url: `${BASE_URL}${request.url}`,
    headers: {
      ...request.headers,
      'x-client-Id': CLIENT_ID,
      'detached-jws': jwsd
    }
  }
}

export const initiateConnection = async (opts: InitiateConnectionDto): Promise<PendingConnectionDto> => {
  const url = '/v1/provider/connections/initiate'

  const request = await authRequest({
    method: 'POST',
    url,
    data: opts
  })

  console.log('done request', request)

  const { data } = await axios(request)
  return data
}

export const createConnection = async (opts: CreateConnectionDto): Promise<ProviderConnectionDto> => {
  const url = '/v1/provider/connections'

  const request = await authRequest({
    method: 'POST',
    url,
    data: opts
  })

  const { data } = await axios(request)
  return data
}

export const getWallets = async () => {
  const url = '/v1/provider/wallets'

  const request = await authRequest({
    method: 'GET',
    url
  })

  const { data } = await axios(request)
  return data
}

export const sendRawRequestToAnchorage = async (request: AxiosRequestConfig) => {
  const url = '/v1/provider/proxy'

  const requestWithAuth = await authRequest({
    ...request,
    url: `${url}${request.url}`
  })

  const { data } = await axios(requestWithAuth)
  return data
}

export const getAccounts = async () => {
  const url = '/v1/provider/accounts'

  const request = await authRequest({
    method: 'GET',
    url
  })

  const { data } = await axios(request)
  return data
}

export const getAddresses = async () => {
  const url = '/v1/provider/addresses'

  const request = await authRequest({
    method: 'GET',
    url
  })

  const { data } = await axios(request)
  return data
}

export type TransferObject = {
  source: {
    type: 'account'
    id: string
  }
  destination: {
    id: string
    type: 'account'
  }
  assetType: string
  amount: string
}
export const createTransfer = async (connectionId: string, transfer: TransferObject) => {
  const body = {
    source: {
      type: 'WALLET',
      id: transfer.source.id
    },
    destination: {
      type: 'WALLET',
      id: transfer.destination.id
    },
    assetType: transfer.assetType,
    amount: transfer.amount
  }

  const request: AxiosRequestConfig = {
    url: '/v2/transfers',
    method: 'POST',
    headers: {
      'x-connection-id': connectionId
    },
    data: body
  }

  const data = sendRawRequestToAnchorage(request)
  return data
}

export const getTransferStatus = async (connectionId: string, transferId: string) => {
  const request: AxiosRequestConfig = {
    url: `/v2/transfers/${transferId}`,
    method: 'GET',
    headers: {
      'x-connection-id': connectionId
    }
  }

  const data = sendRawRequestToAnchorage(request)
  return data
}

export const generateEncryptionKey = async () => {
  const request: AxiosRequestConfig = await authRequest({
    url: '/v1/encryption-keys',
    method: 'POST',
    headers: {
      'x-client-Id': CLIENT_ID
    }
  })

  const { data } = await axios(request)
  return data.data
}
