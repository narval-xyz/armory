import { getWallets } from './provider.utils'

const main = async () => {
  const wallets = await getWallets()

  console.log(wallets)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
