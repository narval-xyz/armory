import { getAddresses } from './provider.utils'

const main = async () => {
  const addresses = await getAddresses()

  console.log(addresses)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
