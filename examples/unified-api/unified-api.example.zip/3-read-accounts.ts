import { getAccounts } from './provider.utils'

const main = async () => {
  const accounts = await getAccounts()

  console.log(accounts)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
