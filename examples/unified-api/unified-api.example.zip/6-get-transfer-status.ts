import dotenv from 'dotenv'
import minimist from 'minimist'
import { getTransferStatus } from './provider.utils'

dotenv.config()

const main = async () => {
  const args = minimist(process.argv.slice(2), {
    string: ['_']
  })

  const connectionId = process.env.CONNECTION_ID

  if (!connectionId) {
    console.error('Please provide CONNECTION_ID in your .env file')
    process.exit(1)
  }
  const transferId = args._[0]

  const status = await getTransferStatus(connectionId, transferId)

  console.log(status)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
