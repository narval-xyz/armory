import { rsaPublicKeySchema } from '@narval-xyz/armory-sdk'
import { rsaEncrypt } from '@narval/signature'
import dotenv from 'dotenv'
import { createConnection, generateEncryptionKey } from './provider.utils'
dotenv.config()

const main = async () => {
  const apiKey = process.env.CONNECTION_API_KEY
  const privateKey = process.env.CONNECTION_PRIVATE_KEY
  const connectionId = process.env.CONNECTION_ID
  const url = process.env.CONNECTION_URL

  if (!apiKey || !privateKey || !connectionId || !url) {
    console.error(
      'Please provide CONNECTION_API_KEY, CONNECTION_PRIVATE_KEY, CONNECTION_ID, and CONNECTION_URL in your .env file'
    )
    process.exit(1)
  }

  const credentials = {
    apiKey,
    privateKey
  }

  const { jwk } = await generateEncryptionKey()
  const encryptionKey = rsaPublicKeySchema.parse(jwk)

  const encryptedCredentials = await rsaEncrypt(JSON.stringify(credentials), encryptionKey)

  const connection = await createConnection({ provider: 'anchorage', encryptedCredentials, url })
  console.dir(connection)
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
