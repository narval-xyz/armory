import { Alg, generateJwk } from '@narval-xyz/armory-sdk'
import { privateKeyToHex, publicKeyToHex } from '@narval-xyz/armory-sdk/signature'

const main = async () => {
  const key = await generateJwk(Alg.EDDSA)
  const privateHexKey = await privateKeyToHex(key)
  const publicHexKey = await publicKeyToHex(key)

  console.log({
    key,
    privateHexKey,
    publicHexKey
  })
}

main()
  .then(() => console.log('done'))
  .catch(console.error)
